package pacote;

import javax.swing.JFrame;

public class Frame {

	public static void main(String[] args) {

		pacmanPanel p = new pacmanPanel();
		p.setFocusable(true);
		p.requestFocus();
		
		
		JFrame f = new JFrame();
		f.add(p);
		f.setSize(475,530);
		f.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		f.setVisible(true);

	}

}

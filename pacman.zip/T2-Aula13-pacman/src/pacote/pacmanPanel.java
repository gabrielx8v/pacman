package pacote;

import java.awt.Graphics;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;
import javax.imageio.ImageIO;
import javax.swing.JPanel;

public class pacmanPanel extends JPanel implements KeyListener{
	
	public pacmanPanel(){
		super();
		addKeyListener(this);
	}
	
	
	public void paintComponent(Graphics g) {
		super.paintComponent(g);
		
		try {
			File f = new File("res/pacman.png");
			BufferedImage i = ImageIO.read(f);
			
			g.drawImage(i, 0, 0, 230*2, 248*2, 230, 0, 450, 248, null);
			g.drawImage(i, 330, y, 230*2, 248*2, 230, 0, 450, 248, null);
		} catch(IOException e) {
			
		}
		
	}


	@Override
	public void keyPressed(KeyEvent arg0) {
		int k = arg0.getKeyCode();
		switch(k) {
		case 37:
			
			break;
		case 38:
			
			break;
		case 39:
			
			break;
		case 40:
			
			break;
		}
		this.repaint();
	}


	@Override
	public void keyReleased(KeyEvent arg0) {
		//System.out.println("tecal solta");
		
	}


	@Override
	public void keyTyped(KeyEvent arg0) {
		//System.out.println("caractere");
		
	}
}
